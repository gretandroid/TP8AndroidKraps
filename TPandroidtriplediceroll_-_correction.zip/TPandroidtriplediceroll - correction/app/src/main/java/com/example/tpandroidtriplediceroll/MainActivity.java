package com.example.tpandroidtriplediceroll;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView dice1ImageView, dice2ImageView, dice3ImageView;
    Button button;
    // 1 - On déclare le ViewModel (MainActivityViewModel)
    MainActivityViewModel mainActivityViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dice1ImageView = findViewById(R.id.dice1ImageView);
        dice2ImageView = findViewById(R.id.dice2ImageView);
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            dice3ImageView = findViewById(R.id.dice3ImageView);
        }

        button = findViewById(R.id.rollButton);

        // 2 - On instancie le ViewModel en utilisant un ViewModelProvider, qui est un objet auquel
        // on va déléguer la gestion du cycle de vie de MainActivityViewModel
        mainActivityViewModel = new ViewModelProvider(this).get(MainActivityViewModel.class);

        // 3 - On récupère les MutableLiveData<>, auquels on applique la méthode observe() pour traquer
        // les changements d'états (ce qui va permettre d'instancier les MutableLiveData<> et de les
        // les initaliser avec les valeurs des variables correspondantes).
        // De plus, la méthode observ() va permettre de définir une fonction qui aura pour paramètre d'entrée
        // le contenu de la MutableLiveData<>, auquel on va affecter un traitement qui va modifier l'ImageView
        // avec l'image correspondante.
        mainActivityViewModel.getDice1().observe(this, value -> dice1ImageView.setImageResource(value));
        mainActivityViewModel.getDice2().observe(this, value -> dice2ImageView.setImageResource(value));
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            mainActivityViewModel.getDice3().observe(this, value -> dice3ImageView.setImageResource(value));
        }
    }

    public void rollButtonOnClick(View view) {
        mainActivityViewModel.rollDices(getResources().getConfiguration().orientation);
    }
}