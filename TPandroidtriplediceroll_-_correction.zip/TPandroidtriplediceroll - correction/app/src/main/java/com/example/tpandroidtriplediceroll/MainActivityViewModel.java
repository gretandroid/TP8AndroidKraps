package com.example.tpandroidtriplediceroll;

import android.content.res.Configuration;
import android.content.res.TypedArray;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.Random;

// Le ViewModel a son propre cycle de vie.
// Lorsque la méthode onDestroy() est appelée sur la MainActivity,
// ViewModel n'est pas détruit et persiste.
public class MainActivityViewModel extends ViewModel {

    // Attributes
    // Tableau des indices des images
    private final static int[] dicesArray = {
            R.drawable.de1,
            R.drawable.de2,
            R.drawable.de3,
            R.drawable.de4,
            R.drawable.de5,
            R.drawable.de6
    };

    // On définit les indices des images qui seront affectés aux ImagesView,
    // recalculés de manière aléatoire dès qu'on clique sur un bouton.
    // Ces trois variables doivent être persistées, même lorsque on change l'orientation
    // du téléphone, et que la MainActivity est détruite.
    private Integer
            _dice1 = dicesArray[0],
            _dice2 = dicesArray[1],
            _dice3 = dicesArray[2];

    // On définit un tableau de LiveData<> qui pourront être modifiées.
    // A chaque fois que les valeurs précédantes seront modifiées, on mettra à jour les
    // MutableLiveData<> correspondantes.
    private MutableLiveData<Integer> dice1, dice2, dice3;

    // Getters
    // On définit des méthodes qui vont renvoyer la valeur des MutableLiveData<> à chaque
    // fois qu'on va les appeler dans la MainActivity.
    // Dans cette méthode, on doit contrôler que la MutableLiveData<> est non-nulle,
    // sinon on l'instancie et on lui affecte la valeur de la variable correspondante.
    public MutableLiveData<Integer> getDice1() {
        if(dice1 == null) {
            dice1 = new MutableLiveData<Integer>();
            dice1.setValue(_dice1);
        }
        return dice1;
    }
    public MutableLiveData<Integer> getDice2() {
        if(dice2 == null) {
            dice2 = new MutableLiveData<Integer>();
            dice2.setValue(_dice2);
        }
        return dice2;
    }
    public MutableLiveData<Integer> getDice3() {
        if(dice3 == null) {
            dice3 = new MutableLiveData<Integer>();
            dice3.setValue(_dice3);
        }
        return dice3;
    }


    // Setters
    // Lorsqu'on modifie la valeur d'une variable, on doit mettre à jour la valeur de
    // la MutableLiveData<> correspondante.
    public void setDice1(Integer dice1) {
        _dice1 = dice1;
        this.dice1.setValue(_dice1);
    }
    public void setDice2(Integer dice2) {
        _dice2 = dice2;
        this.dice2.setValue(_dice2);
    }
    public void setDice3(Integer dice3) {
        _dice3 = dice3;
        this.dice3.setValue(_dice3);
    }


    // Methods
    public void rollDices(int orientation) {
        setDice1(dicesArray[generateRandomIntUpTo(dicesArray.length)]);
        setDice2(dicesArray[generateRandomIntUpTo(dicesArray.length)]);
        if(orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setDice3(dicesArray[generateRandomIntUpTo(dicesArray.length)]);
        }
    }

    private static int generateRandomIntUpTo(int end) {
        int randomNumber;
        Random rand = new Random();
        // NextInt(n) génère un entier (int) alétaoire compris entre 0 inclut et n exclut
        randomNumber = rand.nextInt(end);

        return randomNumber;
    }
}
